$(document).ready(function(){
	
	$("#prob_tag").click(function(){
		//console.log("button clicked");

        $('.tabletaghidden').toggle();

	});
});
